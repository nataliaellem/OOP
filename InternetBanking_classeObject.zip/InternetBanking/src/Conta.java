public class Conta {

    //atributos
    public Cliente dono;
    private String numeroDaConta;
    private double saldo;
    private double limite;
    private Operacao[] operacoes;
    private int posicao_disponivel;
    private static int totalDeContas;

    // Construtor
    public Conta(String tipoCliente){
        if (tipoCliente == "pf") {
            this.dono = new ClientePessoaFisica();
        }
        else if (tipoCliente == "pj") {
            this.dono = new ClientePessoaJuridica();
        }
        else {
            this.dono = new Cliente();
        }
        this.numeroDaConta = "0";
        this.saldo = 0.0;
        this.limite = 0.0;
        this.posicao_disponivel = 0;
        this.operacoes = new Operacao[1000];
        Conta.totalDeContas++;
    }

    //métodos

    // Reimplementando o método toString da superclasse object
    public String toString(){
        String contaStr = "Número da conta: " + this.numeroDaConta + "\n" +
                             "Saldo atual: " + this.saldo + "\n" +
                             "Limite: " + this.limite;
        return contaStr;
    }


    // Reimplementando o método equals da superclasse object
    @Override
    public boolean equals(Object objeto) {
        if (getClass() != objeto.getClass()) return false;
        Conta conta = (Conta) objeto;
        return this.numeroDaConta.equals(conta.numeroDaConta);
    }


    //função que retorna a última posição disponível do vetor operações

    public void proxOperacao(){
        int i = 0;
        while (this.operacoes[i] != null && i < 1000){
            i++;
        }
        this.posicao_disponivel = i;
    }

    //depositar
    public void depositar(double valor){
        this.saldo = this.saldo + valor;
        this.proxOperacao();
        int posicao = this.posicao_disponivel;
        this.operacoes[posicao] = new OperacaoDeposito(valor);
    }

    //sacar
    public boolean sacar(double valor){
        if(valor <= this.saldo){
            this.saldo -= valor;
            this.proxOperacao();
            int posicao = this.posicao_disponivel;
            this.operacoes[posicao] = new OperacaoSaque(valor);
            return true;
        }
        else {
            return false;
        }
    }

    //transferir
    public boolean transferir(Conta contaDestino, double valor){
        boolean retirou;
        if (valor <= this.limite){
            retirou = this.sacar(valor);
        }
        else {
            return false;
        }
        if (retirou) {
            contaDestino.depositar(valor);
            return true;
        }
        else {
            return false;
        }
    }

    //função que imprime o extrato
    public void extrato(){
        for (int i = 0; this.operacoes[i]!=null; i++){
            Operacao o = this.operacoes[i];
            System.out.println(o.getData()+"\t"+o.getTipo()+"\t"+o.getValor());
        }
    }


    //getters

    public String getNumero_da_conta() {
        return this.numeroDaConta;
    }

    public double getSaldo() {
        return this.saldo;
    }

    public double getLimite() {
        return this.limite;
    }

    public int getPosicao_disponivel(){
        return this.posicao_disponivel;
    }

    public static int getTotalDeContas(){
        return Conta.totalDeContas;
    }

    public Operacao getOperacao(int posicao){
        return this.operacoes[posicao];
    }

   //setters

   public void setNumeroDaConta(String numero) {
        this.numeroDaConta = numero;
   }

   public void setLimite(double valor){
        if (valor > 0){
            this.limite = valor;
        }
        else {
            this.limite = 0;
        }
   }

}


