public class Conta {

    //atributos
    public Cliente dono;
    private String numeroDaConta;
    private double saldo;
    private double limite;

    private Operacao[] operacoes;
    private int numOperacoes;

    public static int TOTAL_CONTAS = 0;


    // Construtor
    public Conta(String tipoCliente){
        if (tipoCliente == "pf") {
            this.dono = new ClientePessoaFisica();
        }
        else if (tipoCliente == "pj") {
            this.dono = new ClientePessoaJuridica();
        }
        else {
            this.dono = new Cliente();
        }
        this.saldo = 0.0;
        this.limite = 0.0;

        this.numOperacoes = 0;
        this.operacoes = new Operacao[1000];

        Conta.TOTAL_CONTAS++;
    }

    //métodos

    // Reimplementando o método toString da superclasse object
    public String toString(){
        String contaStr = "Número da conta: " + this.numeroDaConta + "\n" +
                             "Saldo atual: " + this.saldo + "\n" +
                             "Limite: " + this.limite;
        return contaStr;
    }


    // Reimplementando o método equals da superclasse object
    @Override
    public boolean equals(Object objeto) {
        if (getClass() != objeto.getClass()) return false;
        Conta conta = (Conta) objeto;
        return this.numeroDaConta.equals(conta.numeroDaConta);
    }


    //depositar
    public void depositar(double valor){
        this.saldo = this.saldo + valor;
        this.operacoes[numOperacoes] = new OperacaoDeposito(valor);
        numOperacoes++;
    }

    //sacar
    public boolean sacar(double valor){
        if(valor <= this.saldo){
            this.saldo -= valor;
            this.operacoes[numOperacoes] = new OperacaoSaque(valor);
            numOperacoes++;
            return true;
        }
        else {
            return false;
        }
    }

    //transferir
    public boolean transferir(Conta contaDestino, double valor){
        boolean retirou;
        if (valor <= this.limite){
            retirou = this.sacar(valor);
        }
        else {
            return false;
        }
        if (retirou) {
            contaDestino.depositar(valor);
            return true;
        }
        else {
            return false;
        }
    }

    //função que imprime o extrato

    public void imprimirExtrato(){
        for (int i = 0; i < this.numOperacoes; i++){
            this.operacoes[i].imprimir();
        }
    }


    //getters

    public String getNumeroDaConta() {
        return this.numeroDaConta;
    }

    public double getSaldo() {
        return this.saldo;
    }

    public double getLimite() {
        return this.limite;
    }

    public Operacao getOperacao(int posicao){
        return this.operacoes[posicao];
    }

   //setters

   public void setNumeroDaConta(String numero) {
        this.numeroDaConta = numero;
   }

   public void setLimite(double valor){
        if (valor > 0){
            this.limite = valor;
        }
        else {
            this.limite = 0;
        }
   }

}


