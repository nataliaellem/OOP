public class Main {
    public static void main(String[] args){

        //Criando o primeiro usuário
        Conta user1 = new Conta("pf");
        user1.setNumeroDaConta("1");
        user1.setLimite(2000.0);

        ClientePessoaFisica user1Conta = new ClientePessoaFisica();
        user1Conta.setNome("Maria");
        user1Conta.setEndereco("Brasil");
        user1Conta.setData("01/01/2021");
        user1Conta.setCpf("123");
        user1Conta.setSexo('f');
        user1Conta.setIdade(21);
        user1.dono = user1Conta;

        //Criando o segundo usuário
        Conta user2 = new Conta("pj");
        user2.setNumeroDaConta("2");
        user2.setLimite(300);

        user2.dono.setNome("José");
        user2.dono.setEndereco("Brasil");
        user2.dono.setData("01/01/2021");
        ((ClientePessoaJuridica) user2.dono).setCnpj("987");
        ((ClientePessoaJuridica) user2.dono).setSetor("TI");
        ((ClientePessoaJuridica) user2.dono).setNumFuncionarios(100);

        //Operações
        user1.depositar(10000);
        user1.depositar(5000);
        user1.sacar(400);
        user1.sacar(7000);

        user2.depositar(10000);
        user2.transferir(user1, 400);
        user2.sacar(1000);


        //Testando a função toString reimplementada nas classes
        //ClientePessoaFisica, ClientePessoaJuridica, Conta, OperacaoDeposito,
        //OperacaoSaque
        System.out.println(user1.dono.toString());
        System.out.println("\n");
        System.out.println(user2.dono.toString());
        System.out.println("\n");
        System.out.println(user1.getOperacao(0).toString());
        System.out.println("\n");
        System.out.println(user1.getOperacao(2).toString());
        System.out.println("\n");
        System.out.println(user1.getOperacao(2));


        // Testando a função equals reimplementada nas classes
        // Conta, ClientePessoaFisica, ClientePessoaJuridica

        //Criando uma conta com o mesmo número da conta da Maria para testar
        Conta maria = new Conta("pf");
        maria.setNumeroDaConta("1");

        if (maria.equals(user1)){
            System.out.println("As contas são iguais.");
        } else {
            System.out.println("As contas são diferentes.");
        }

        // Criando dois clientes do tipo pessoa juridica para testar se são iguais

        ClientePessoaJuridica cliente1 = new ClientePessoaJuridica();
        cliente1.setCnpj("123");

        ClientePessoaJuridica cliente2 = new ClientePessoaJuridica();
        cliente2.setCnpj("123");

        if (cliente1.equals(cliente2)){
            System.out.println("Os clientes são iguais");
        } else {
            System.out.println("Os clientes são diferentes");
        }
    }
}
