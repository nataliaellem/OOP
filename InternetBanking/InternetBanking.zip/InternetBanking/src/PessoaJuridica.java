public class PessoaJuridica extends Cliente {
    private String cnpj;
    private int numFuncionarios;
    String setor;

    //Métodos
    public void imprimir(){
        System.out.println("Nome: " + super.getNome());
        System.out.println("Endereço: " + super.getEndereco());
        System.out.println("Data: " + super.getData());
        System.out.println("CNPJ: " + this.cnpj);
        System.out.println("Número de funcionários: " + this.numFuncionarios);
        System.out.println("Setor: " + this.setor);
    }

    // Getters
    public String getCnpj() {
        return this.cnpj;
    }

    public String getSetor() {
        return this.setor;
    }

    public int getNumFuncionarios() {
        return this.numFuncionarios;
    }


    //Setters

    public void setCnpj(String cnpj) {
        this.cnpj = cnpj;
    }

    public void setSetor(String setor) {
            this.setor = setor;
    }

    public void setNumFuncionarios(int numFuncionarios) {
        this.numFuncionarios = numFuncionarios;
    }
}


