public class OperacaoDeposito extends Operacao {

    public OperacaoDeposito(double valor) {
        super.setTipo('d');
        super.setValor(valor);
    }

}
