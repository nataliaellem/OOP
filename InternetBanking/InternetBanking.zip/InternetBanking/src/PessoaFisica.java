public class PessoaFisica extends Cliente {

    private String cpf;
    private int idade;
    private char sexo;


    // Métodos

    public PessoaFisica() {
        this.cpf = null;
        this.idade = 0;
    }

    public void imprimir() {
        System.out.println("Nome: " + super.getNome());
        System.out.println("Endereço: " + super.getEndereco());
        System.out.println("Data: " + super.getData());
        System.out.println("CPF: " + this.cpf);
        System.out.println("Sexo: " + this.sexo);
        System.out.println("Idade: " + this.idade);
    }


    // Getters
    public String getCpf() {
        return this.cpf;
    }

    public char getSexo() {
        return this.sexo;
    }

    public int getIdade() {
        return this.idade;
    }


    //Setters

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public void setSexo(char sexo) {
        if (sexo == 'm' || sexo == 'f')
        this.sexo = sexo;
    }

    public void setIdade(int idade) {
        this.idade = idade;
    }
}
