public class Main {
    public static void main(String[] args){

        //Criando o primeiro usuário
        Conta user1 = new Conta("pf");
        user1.setNumeroDaConta(1);
        user1.setLimite(2000.0);

        user1.dono.setNome("Maria");
        user1.dono.setEndereco("Brasil");
        user1.dono.setData("01/01/2021");
        ((PessoaFisica) user1.dono).setCpf("123");
        ((PessoaFisica) user1.dono).setSexo('f');
        ((PessoaFisica) user1.dono).setIdade(21);

        //Criando o segundo usuário
        Conta user2 = new Conta("pj");
        user2.setNumeroDaConta(2);
        user2.setLimite(300);

        user2.dono.setNome("José");
        user2.dono.setEndereco("Brasil");
        user2.dono.setData("01/01/2021");
        ((PessoaJuridica) user2.dono).setCnpj("987");
        ((PessoaJuridica) user2.dono).setSetor("TI");
        ((PessoaJuridica) user2.dono).setNumFuncionarios(100);

        //Operações
        user1.depositar(10000);
        user1.depositar(5000);
        user1.sacar(400);
        user1.sacar(7000);

        user2.depositar(10000);
        user2.transferir(user1, 400);
        user2.sacar(1000);

        user1.dono.imprimir();
        System.out.println("\n");
        user2.dono.imprimir();
    }
}
