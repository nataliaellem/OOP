public class OperacaoSaque extends Operacao {

    public OperacaoSaque(double valor){
        super.setTipo('s');
        super.setValor(valor);
    }

}
