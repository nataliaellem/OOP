
public class Conta {

    //atributos
    private final Cliente dono = new Cliente();
    private int numeroDaConta;
    private double saldo;
    private double limite;
    private Operacao[] operacoes = new Operacao[1000];
    private int posicao_disponivel;
    private static int totalDeContas;

    // Construtor
    public Conta(){
        this.numeroDaConta = -1;
        this.dono.setNome("Inválido");
        this.saldo = 0.0;
        this.limite = 0.0;
        this.posicao_disponivel = 0;
        Conta.totalDeContas++;
    }

    //métodos

    //função que retorna a última posição disponível do vetor operações

    public void proxOperacao(){
        int i = 0;
        while (this.operacoes[i] != null && i < 1000){
            i++;
        }
        this.posicao_disponivel = i;
    }

    //depositar
    public void depositar(double valor){
        this.saldo = this.saldo + valor;
        this.proxOperacao();
        int posicao = this.posicao_disponivel;
        this.operacoes[posicao] = new Operacao('d', valor);
    }

    //sacar
    public boolean sacar(double valor){
        if(valor <= this.saldo){
            this.saldo -= valor;
            this.proxOperacao();
            int posicao = this.posicao_disponivel;
            this.operacoes[posicao] = new Operacao('s', valor);
            return true;
        }
        else {
            return false;
        }
    }

    //transferir
    public boolean transferir(Conta contaDestino, double valor){
        boolean retirou;
        if (valor <= this.limite){
            retirou = this.sacar(valor);
        }
        else {
            return false;
        }
        if (retirou) {
            contaDestino.depositar(valor);
            return true;
        }
        else {
            return false;
        }
    }

    //função que imprime o extrato
    public void extrato(){
        for (int i = 0; this.operacoes[i]!=null; i++){
            Operacao o = this.operacoes[i];
            System.out.println(o.getData()+"\t"+o.getTipo()+"\t"+o.getValor());
        }
    }

    //imprimir
    public void imprimir(){
        System.out.println("Nome: "+this.dono.getNomeCliente());
        System.out.println("Número da conta: "+this.numeroDaConta);
        System.out.println("Saldo atual: "+this.saldo);
        System.out.println("Limite: "+this.limite);
    }

    //getters

    public int getNumero_da_conta() {
        return this.numeroDaConta;
    }

    public double getSaldo() {
        return this.saldo;
    }

    public double getLimite() {
        return this.limite;
    }

    public int getPosicao_disponivel(){
        return this.posicao_disponivel;
    }

    public static int getTotalDeContas(){
        return Conta.totalDeContas;
    }


   //setters

   public void setNumeroDaConta(int valor) {
        this.numeroDaConta = valor;
   }

   public void setLimite(double valor){
        if (valor > 0){
            this.limite = valor;
        }
        else {
            this.limite = 0;
        }
   }


   //setters do atributo dono que é do tipo Cliente

   public void setNomeDono(String nomeDono){
        this.dono.setNome(nomeDono);
   }
   public void setCpfDono(String cpf){
        this.dono.setCPF(cpf);
   }

   public void setDonoEndereco(String endereco){
        this.dono.setEndereco(endereco);
   }

   public void setDonoIdade(int idade){
        this.dono.setIdade(idade);
   }

   public void setDonoSexo(char sexo){
        this.dono.setSexo(sexo);
   }

}


