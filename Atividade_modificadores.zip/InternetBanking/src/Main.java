public class Main {
    public static void main(String[] args){

        //Criando o primeiro usuário
        Conta user1 = new Conta();
        user1.setNumeroDaConta(1);
        user1.setLimite(2000.0);

        user1.setNomeDono("Maria");
        user1.setDonoSexo('f');
        user1.setDonoEndereco("Brasil");
        user1.setCpfDono("123");
        user1.setDonoIdade(30);

        //Criando o segundo usuário
        Conta user2 = new Conta();
        user2.setNumeroDaConta(2);
        user2.setLimite(300);

        user2.setNomeDono("Joana");
        user2.setCpfDono("321");
        user2.setDonoEndereco("America");
        user2.setDonoSexo('f');
        user2.setDonoIdade(25);

        //Terceiro usuário
        Conta user3 = new Conta();
        user3.setNumeroDaConta(2);
        user3.setLimite(500);

        user3.setNomeDono("José");
        user3.setCpfDono("213");
        user3.setDonoEndereco("Minas Gerais");
        user3.setDonoSexo('m');
        user3.setDonoIdade(25);

        //Operações
        user1.depositar(10000);
        user1.depositar(5000);
        user1.sacar(400);
        user1.sacar(7000);

        user2.depositar(10000);
        user2.transferir(user1, 400);
        user2.sacar(1000);

        user3.depositar(25000);
        user3.transferir(user1, 400);
        user3.transferir(user2, 200);
        user3.depositar(1000);
        user3.sacar(200);


        //Média de operações realizadas em relação ao número de contas
        int TotalOperacoes = Operacao.getTotalOperacoes();
        int TotalContas = Conta.getTotalDeContas();
        int media = TotalOperacoes / TotalContas;
        System.out.println("A média de operações realizadas em relação às contas é: "+media);

    }
}
