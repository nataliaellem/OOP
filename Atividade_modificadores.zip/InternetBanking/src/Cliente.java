public class Cliente {
    private String nome;
    private String CPF;
    private String endereco;
    private int idade;
    private char sexo;

    //Métodos paara obter os atributos do cliente
    public String getNomeCliente(){
        return this.nome;
    }


    //getters
    public String getNome(){
        return this.nome;

    }
    public String getCPFCliente(){
        return this.CPF;
    }

    public String getEnderecoCliente(){
        return this.endereco;
    }

    public int getIdadeCliente(){
        return this.idade;
    }

    public char getSexo() {
        return this.sexo;
    }


    //setters

    public void setNome(String nome){
        this.nome = nome;
    }

    public void setCPF(String cpf){
        this.CPF = cpf;
    }

    public void setEndereco(String endereco){
        this.endereco = endereco;
    }

    public void setSexo(char sexo){
        this.sexo = sexo;
    }

    public void setIdade(int idade){
        this.idade = idade;
    }
}
