public interface ITaxas {

    public double calculaTaxas();

}
